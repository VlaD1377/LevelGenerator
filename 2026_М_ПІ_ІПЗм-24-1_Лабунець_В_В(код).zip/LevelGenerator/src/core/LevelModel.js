export default class LevelModel {
    constructor(width, height, fillValue = 0) {
        this.width = width;
        this.height = height;

        this.tiles = [];
        this.rooms = [];
        this.metadata = {};

        for (let y = 0; y < height; y++) {
            this.tiles[y] = [];
            for (let x = 0; x < width; x++) {
                this.tiles[y][x] = fillValue;
            }
        }
    }

    isInside(x, y) {
        return x >= 0 && x < this.width && y >= 0 && y < this.height;
    }

    getTile(x, y) {
        if (!this.isInside(x, y)) {
            return null;
        }
        return this.tiles[y][x];
    }

    setTile(x, y, value) {
        if (!this.isInside(x, y)) {
            return;
        }
        this.tiles[y][x] = value;
    }

    addRoom(room) {
        this.rooms.push(room);
    }
}