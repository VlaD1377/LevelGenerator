export default class MetricsBatchRunner {
    constructor(generationManager, levelAnalyzer) {
        this.generationManager = generationManager;
        this.levelAnalyzer = levelAnalyzer;
    }

    runForAlgorithm(algorithmName, configData, runs = 20) {
        const results = [];

        for (let i = 0; i < runs; i++) {
            const level = this.generationManager.generate(algorithmName, configData);
            const metrics = this.levelAnalyzer.analyze(level);
            results.push(metrics);
        }

        return {
            algorithm: algorithmName,
            runs,
            average: this.calculateAverage(results),
            min: this.calculateMin(results),
            max: this.calculateMax(results),
            raw: results
        };
    }

    runForAlgorithms(algorithmNames, configData, runs = 20) {
        const summary = {};

        for (const algorithmName of algorithmNames) {
            const localConfig = this.cloneConfig(configData);
            localConfig.general.algorithm = algorithmName;

            summary[algorithmName] = this.runForAlgorithm(algorithmName, localConfig, runs);
        }

        return summary;
    }

    calculateAverage(results) {
        if (results.length === 0) {
            return {};
        }

        const numericKeys = this.getNumericKeys(results[0]);
        const sums = {};

        for (const key of numericKeys) {
            sums[key] = 0;
        }

        for (const result of results) {
            for (const key of numericKeys) {
                sums[key] += result[key];
            }
        }

        const average = {};
        for (const key of numericKeys) {
            average[key] = +(sums[key] / results.length).toFixed(3);
        }

        return average;
    }

    calculateMin(results) {
        if (results.length === 0) {
            return {};
        }

        const numericKeys = this.getNumericKeys(results[0]);
        const minValues = {};

        for (const key of numericKeys) {
            minValues[key] = Infinity;
        }

        for (const result of results) {
            for (const key of numericKeys) {
                if (result[key] < minValues[key]) {
                    minValues[key] = result[key];
                }
            }
        }

        for (const key of numericKeys) {
            minValues[key] = +minValues[key].toFixed(3);
        }

        return minValues;
    }

    calculateMax(results) {
        if (results.length === 0) {
            return {};
        }

        const numericKeys = this.getNumericKeys(results[0]);
        const maxValues = {};

        for (const key of numericKeys) {
            maxValues[key] = -Infinity;
        }

        for (const result of results) {
            for (const key of numericKeys) {
                if (result[key] > maxValues[key]) {
                    maxValues[key] = result[key];
                }
            }
        }

        for (const key of numericKeys) {
            maxValues[key] = +maxValues[key].toFixed(3);
        }

        return maxValues;
    }

    getNumericKeys(obj) {
        return Object.keys(obj).filter(key => typeof obj[key] === 'number');
    }

    cloneConfig(config) {
        return JSON.parse(JSON.stringify(config));
    }
}