export default class LevelAnalyzer {
    analyze(levelModel) {
        const totalTiles = levelModel.width * levelModel.height;
        const walkableTiles = this.countWalkableTiles(levelModel);
        const walkableRatio = totalTiles > 0 ? +(walkableTiles / totalTiles).toFixed(3) : 0;

        const components = this.findConnectedComponents(levelModel);
        const componentCount = components.length;
        const largestComponentSize = components.length > 0 ? components[0].length : 0;
        const largestComponentRatio = walkableTiles > 0 ? +(largestComponentSize / walkableTiles).toFixed(3) : 0;

        const straightWallRatio = this.calculateStraightWallMetrics(levelModel, 6);

        return {
            walkableRatio,
            componentCount,
            largestComponentRatio,
            straightWallRatio
        };
    }

    isWalkable(tile) {
        return tile === 1 || tile === 2;
    }

    isWall(tile) {
        return tile === 0;
    }

    countWalkableTiles(levelModel) {
        let count = 0;

        for (let y = 0; y < levelModel.height; y++) {
            for (let x = 0; x < levelModel.width; x++) {
                if (this.isWalkable(levelModel.getTile(x, y))) {
                    count++;
                }
            }
        }

        return count;
    }

    findConnectedComponents(levelModel) {
        const visited = Array.from({ length: levelModel.height }, () =>
            Array(levelModel.width).fill(false)
        );

        const components = [];

        for (let y = 0; y < levelModel.height; y++) {
            for (let x = 0; x < levelModel.width; x++) {
                if (!visited[y][x] && this.isWalkable(levelModel.getTile(x, y))) {
                    const component = this.floodFill(levelModel, x, y, visited);
                    components.push(component);
                }
            }
        }

        components.sort((a, b) => b.length - a.length);
        return components;
    }

    floodFill(levelModel, startX, startY, visited) {
        const queue = [{ x: startX, y: startY }];
        const component = [];
        visited[startY][startX] = true;

        const dirs = [
            { x: 1, y: 0 },
            { x: -1, y: 0 },
            { x: 0, y: 1 },
            { x: 0, y: -1 }
        ];

        while (queue.length > 0) {
            const current = queue.shift();
            component.push(current);

            for (const d of dirs) {
                const nx = current.x + d.x;
                const ny = current.y + d.y;

                if (
                    levelModel.isInside(nx, ny) &&
                    !visited[ny][nx] &&
                    this.isWalkable(levelModel.getTile(nx, ny))
                ) {
                    visited[ny][nx] = true;
                    queue.push({ x: nx, y: ny });
                }
            }
        }

        return component;
    }

    calculateStraightWallMetrics(levelModel, minLength = 6) {
        let contourWallCount = 0;
        let straightWallTotalLength = 0;

        const contourMap = Array.from({ length: levelModel.height }, () =>
            Array(levelModel.width).fill(false)
        );

        for (let y = 1; y < levelModel.height - 1; y++) {
            for (let x = 1; x < levelModel.width - 1; x++) {
                if (this.isContourWall(levelModel, x, y)) {
                    contourMap[y][x] = true;
                    contourWallCount++;
                }
            }
        }

        for (let y = 1; y < levelModel.height - 1; y++) {
            let run = 0;

            for (let x = 1; x < levelModel.width - 1; x++) {
                if (contourMap[y][x]) {
                    run++;
                } else {
                    if (run >= minLength) {
                        straightWallTotalLength += run;
                    }
                    run = 0;
                }
            }

            if (run >= minLength) {
                straightWallTotalLength += run;
            }
        }

        for (let x = 1; x < levelModel.width - 1; x++) {
            let run = 0;

            for (let y = 1; y < levelModel.height - 1; y++) {
                if (contourMap[y][x]) {
                    run++;
                } else {
                    if (run >= minLength) {
                        straightWallTotalLength += run;
                    }
                    run = 0;
                }
            }

            if (run >= minLength) {
                straightWallTotalLength += run;
            }
        }

        return contourWallCount > 0 ? +(straightWallTotalLength / contourWallCount).toFixed(3) : 0;
    }

    isContourWall(levelModel, x, y) {
        if (!this.isWall(levelModel.getTile(x, y))) {
            return false;
        }

        const dirs = [
            { x: 1, y: 0 },
            { x: -1, y: 0 },
            { x: 0, y: 1 },
            { x: 0, y: -1 }
        ];

        for (const d of dirs) {
            const nx = x + d.x;
            const ny = y + d.y;

            if (!levelModel.isInside(nx, ny)) {
                continue;
            }

            if (this.isWalkable(levelModel.getTile(nx, ny))) {
                return true;
            }
        }

        return false;
    }
}