import BSPGenerator from '../algorithms/BSPGenerator.js';
import CellularAutomataGenerator from '../algorithms/CellularAutomataGenerator.js';
import PerlinNoiseGenerator from '../algorithms/PerlinNoiseGenerator.js';
import RandomWalkGenerator from '../algorithms/RandomWalkGenerator.js';
import HybridGenerator from '../algorithms/HybridGenerator.js';

export default class GenerationManager {
    constructor() {
        this.generators = {
            BSP: new BSPGenerator(),
            HYBRID: new HybridGenerator(),
            CA: new CellularAutomataGenerator(),
            PERLIN: new PerlinNoiseGenerator(),
            RW: new RandomWalkGenerator(),
        };
    }

    generate(algorithmName, config) {
        const generator = this.generators[algorithmName];

        if (!generator) {
            throw new Error(`Unknown generation algorithm: ${algorithmName}`);
        }

        return generator.generate(config);
    }
}