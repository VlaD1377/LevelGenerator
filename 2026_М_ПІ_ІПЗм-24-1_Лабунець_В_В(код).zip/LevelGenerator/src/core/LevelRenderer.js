export default class LevelRenderer {
    constructor(scene, tileSize) {
        this.scene = scene;
        this.tileSize = tileSize;
    }

    render(levelModel) {
        this.drawMap(levelModel);
        this.drawUI(levelModel);
    }

    drawMap(levelModel) {
        const graphics = this.scene.add.graphics();

        for (let y = 0; y < levelModel.height; y++) {
            for (let x = 0; x < levelModel.width; x++) {
                const tile = levelModel.tiles[y][x];

                if (tile === 1) {
                    graphics.fillStyle(0xe8e8e8, 1);
                } else if (tile === 2) {
                    graphics.fillStyle(0xa0a0a0, 1);
                } else {
                    graphics.fillStyle(0x2b2b2b, 1);
                }

                graphics.fillRect(
                    x * this.tileSize,
                    y * this.tileSize,
                    this.tileSize - 1,
                    this.tileSize - 1
                );
            }
        }
    }

    drawUI(levelModel) {
        const panelX = 10;
        const panelY = 10;
        
        const metrics = levelModel.metadata.metrics || {};

        const stats = [
            `Algorithm: ${levelModel.metadata.algorithm}`,
            `Map: ${levelModel.metadata.mapSize}`,
            `Walkable ratio W: ${metrics.walkableRatio ?? '-'}`,
            `Components: ${metrics.componentCount ?? '-'}`,
            `Largest component ratio L: ${metrics.largestComponentRatio ?? '-'}`,
            `Straight wall ratio S: ${metrics.straightWallRatio ?? '-'}`,
        ];

        const bg = this.scene.add.graphics();
        bg.fillStyle(0x000000, 0.65);
        bg.fillRoundedRect(panelX - 8, panelY - 8, 260, 180, 8);

        this.scene.add.text(panelX, panelY, stats.join('\n'), {
            font: '16px Arial',
            color: '#ffffff',
            lineSpacing: 6
        }).setDepth(10);
    }
}