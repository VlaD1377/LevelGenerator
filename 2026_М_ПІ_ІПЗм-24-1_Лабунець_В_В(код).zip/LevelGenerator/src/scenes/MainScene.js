import GenerationManager from '../core/GenerationManager.js';
import LevelRenderer from '../core/LevelRenderer.js';
import LevelAnalyzer from '../core/LevelAnalyzer.js';
import MetricsBatchRunner from '../core/MetricsBatchRunner.js';
import generationConfig from '../config.js';

export default class MainScene extends Phaser.Scene {
    constructor() {
        super('MainScene');
    }

    create() {
        this.configData = structuredClone(generationConfig);

        this.tileSize = this.configData.general.tileSize;

        this.generationManager = new GenerationManager();
        this.levelRenderer = new LevelRenderer(this, this.tileSize);
        this.levelAnalyzer = new LevelAnalyzer();

        this.metricsBatchRunner = new MetricsBatchRunner(
            this.generationManager,
            this.levelAnalyzer
        );

        this.bindKeys();
        this.buildLevel();
    }

    bindKeys() {
        this.input.keyboard.on('keydown-R', () => {
            this.buildLevel();
        });

        this.input.keyboard.on('keydown-ONE', () => {
            this.configData.general.algorithm = 'BSP';
            this.buildLevel();
        });

        this.input.keyboard.on('keydown-TWO', () => {
            this.configData.general.algorithm = 'CA';
            this.buildLevel();
        });

        this.input.keyboard.on('keydown-THREE', () => {
            this.configData.general.algorithm = 'PERLIN';
            this.buildLevel();
        });

        this.input.keyboard.on('keydown-FOUR', () => {
            this.configData.general.algorithm = 'RW';
            this.buildLevel();
        });

        this.input.keyboard.on('keydown-FIVE', () => {
            this.configData.general.algorithm = 'HYBRID';
            this.buildLevel();
        });
    }

    buildLevel() {
        this.children.removeAll();

        const algorithmName = this.configData.general.algorithm;
        const level = this.generationManager.generate(algorithmName, this.configData);

        const metrics = this.levelAnalyzer.analyze(level);
        level.metadata.metrics = metrics;

        this.levelRenderer.render(level);

        this.createExperimentButton();
    }
    
    createExperimentButton() {
        const runButton = this.add.text(10, 160, 'Run Experiments', {
            fontSize: '16px',
            fill: '#ffffff'
        }).setInteractive().setDepth(20);

        runButton.on('pointerdown', () => {
            const summary = this.metricsBatchRunner.runForAlgorithms(
                ['BSP', 'CA', 'PERLIN', 'RW', 'HYBRID'],
                this.configData,
                100
            );

            console.log('Experiment results');
            console.log(summary);
        });
    }
}