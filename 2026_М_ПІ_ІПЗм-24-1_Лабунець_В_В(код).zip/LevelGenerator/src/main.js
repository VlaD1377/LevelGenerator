import MainScene from './scenes/MainScene.js';

const config = {
    type: Phaser.AUTO,
    width: 1800,
    height: 900,
    backgroundColor: '#1e1e1e',
    scene: [MainScene]
};

new Phaser.Game(config);