import LevelModel from '../core/LevelModel.js';

export default class PerlinNoiseGenerator {
    generate(config) {
        const general = config.general || {};
        const perlin = config.perlin || {};

        const defaultGeneral = {
            mapWidth: 100,
            mapHeight: 60
        };

        const defaultPerlin = {
            scale: 12,
            threshold: 0.5,
            octaves: 3,
            persistence: 0.5,
            smoothSteps: 2
        };

        this.general = { ...defaultGeneral, ...general };
        this.perlin = { ...defaultPerlin, ...perlin };
        this.offsetX = Math.random() * 10000;
        this.offsetY = Math.random() * 10000;
        this.level = new LevelModel(this.general.mapWidth, this.general.mapHeight, 0);
        this.noiseMap = this.generateNoiseMap();
        this.convertNoiseToBinaryMap();

        for (let i = 0; i < this.perlin.smoothSteps; i++) {
            this.smoothBinaryMap();
        }

        this.convertToLevelTiles();
        this.calculateMetadata();
        return this.level;
    }

    generateNoiseMap() {
        const map = [];

        for (let y = 0; y < this.general.mapHeight; y++) {
            map[y] = [];

            for (let x = 0; x < this.general.mapWidth; x++) {
                let amplitude = 1;
                let frequency = 1;
                let noiseHeight = 0;
                let maxValue = 0;

                for (let octave = 0; octave < this.perlin.octaves; octave++) {
                    const sampleX = ((x + this.offsetX) / this.perlin.scale) * frequency;
                    const sampleY = ((y + this.offsetY) / this.perlin.scale) * frequency;

                    const value = this.smoothNoise(sampleX, sampleY);

                    noiseHeight += value * amplitude;
                    maxValue += amplitude;

                    amplitude *= this.perlin.persistence;
                    frequency *= 2;
                }

                noiseHeight /= maxValue;
                map[y][x] = noiseHeight;
            }
        }

        return map;
    }

    smoothNoise(x, y) {
        const x0 = Math.floor(x);
        const x1 = x0 + 1;
        const y0 = Math.floor(y);
        const y1 = y0 + 1;
        const sx = x - x0;
        const sy = y - y0;
        const n0 = this.random2D(x0, y0);
        const n1 = this.random2D(x1, y0);
        const ix0 = this.lerp(n0, n1, this.fade(sx));
        const n2 = this.random2D(x0, y1);
        const n3 = this.random2D(x1, y1);
        const ix1 = this.lerp(n2, n3, this.fade(sx));

        return this.lerp(ix0, ix1, this.fade(sy));
    }

    random2D(x, y) {
        const value = Math.sin(x * 127.1 + y * 311.7) * 43758.5453123;
        return value - Math.floor(value);
    }

    fade(t) {
        return t * t * (3 - 2 * t);
    }

    lerp(a, b, t) {
        return a + (b - a) * t;
    }

    convertNoiseToBinaryMap() {
        this.map = [];

        for (let y = 0; y < this.general.mapHeight; y++) {
            this.map[y] = [];
            for (let x = 0; x < this.general.mapWidth; x++) {
                const isBorder = x === 0 || y === 0 || x === this.general.mapWidth - 1 || y === this.general.mapHeight - 1;

                if (isBorder) {
                    this.map[y][x] = 1;
                } else {
                    this.map[y][x] = this.noiseMap[y][x] > this.perlin.threshold ? 1 : 0;
                }
            }
        }
    }

    smoothBinaryMap() {
        const newMap = [];

        for (let y = 0; y < this.general.mapHeight; y++) {
            newMap[y] = [];

            for (let x = 0; x < this.general.mapWidth; x++) {
                const isBorder = x === 0 || y === 0 || x === this.general.mapWidth - 1 || y === this.general.mapHeight - 1;
                if (isBorder) {
                    newMap[y][x] = 1;
                    continue;
                }

                const neighboringWalls = this.countWallNeighbors(x, y);
                if (neighboringWalls >= 5) {
                    newMap[y][x] = 1;
                } else if (neighboringWalls <= 3) {
                    newMap[y][x] = 0;
                } else {
                    newMap[y][x] = this.map[y][x];
                }
            }
        }

        this.map = newMap;
    }

    countWallNeighbors(x, y) {
        let count = 0;

        for (let offsetY = -1; offsetY <= 1; offsetY++) {
            for (let offsetX = -1; offsetX <= 1; offsetX++) {
                if (offsetX === 0 && offsetY === 0) {
                    continue;
                }

                const nx = x + offsetX;
                const ny = y + offsetY;
                if (nx < 0 || ny < 0 || nx >= this.general.mapWidth || ny >= this.general.mapHeight) {
                    count++;
                } else if (this.map[ny][nx] === 1) {
                    count++;
                }
            }
        }

        return count;
    }

    convertToLevelTiles() {
        for (let y = 0; y < this.general.mapHeight; y++) {
            for (let x = 0; x < this.general.mapWidth; x++) {
                if (this.map[y][x] === 1) {
                    this.level.setTile(x, y, 0);
                } else {
                    this.level.setTile(x, y, 1);
                }
            }
        }
    }

    calculateMetadata() {
        let floorCount = 0;
        let wallCount = 0;

        for (let y = 0; y < this.level.height; y++) {
            for (let x = 0; x < this.level.width; x++) {
                const tile = this.level.getTile(x, y);

                if (tile === 0) {
                    wallCount++;
                } else {
                    floorCount++;
                }
            }
        }

        const totalTiles = this.level.width * this.level.height;
        const actualFloorRatio = totalTiles > 0 ? floorCount / totalTiles : 0;

        this.level.metadata.algorithm = 'Perlin Noise';
        this.level.metadata.mapSize = `${this.general.mapWidth} x ${this.general.mapHeight}`;
        this.level.metadata.scale = this.perlin.scale;
        this.level.metadata.threshold = this.perlin.threshold;
        this.level.metadata.octaves = this.perlin.octaves;
        this.level.metadata.persistence = this.perlin.persistence;
        this.level.metadata.smoothSteps = this.perlin.smoothSteps;
        this.level.metadata.floorCount = floorCount;
        this.level.metadata.wallCount = wallCount;
        this.level.metadata.actualFloorRatio = actualFloorRatio.toFixed(3);
    }
}