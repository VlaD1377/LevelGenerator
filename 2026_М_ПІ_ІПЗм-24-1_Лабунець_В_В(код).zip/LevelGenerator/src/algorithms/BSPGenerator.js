import LevelModel from '../core/LevelModel.js';

class BSPNode {
    constructor(x, y, w, h) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;

        this.left = null;
        this.right = null;
        this.room = null;
    }
}

export default class BSPGenerator {
    generate(config) {
        const general = config.general || {};
        const bsp = config.bsp || {};

        const defaultGeneral = {
            mapWidth: 100,
            mapHeight: 60
        };

        const defaultBsp = {
            minPartitionSize: 14,
            maxDepth: 5,
            roomPadding: 1,
            minRoomWidth: 5,
            minRoomHeight: 5,
            minAspectRatio: 0.65,
            maxAspectRatio: 1.7,
            maxRoomPlacementAttempts: 20
        };

        this.general = { ...defaultGeneral, ...general };
        this.bsp = { ...defaultBsp, ...bsp };

        this.level = new LevelModel(this.general.mapWidth, this.general.mapHeight, 0);
        const root = new BSPNode(1, 1, this.general.mapWidth - 2, this.general.mapHeight - 2);

        this.splitNode(root, 0);
        this.createRooms(root);
        this.connectRooms(root);
        this.calculateMetadata();
        return this.level;
    }

    splitNode(node, depth) {
        if (depth >= this.bsp.maxDepth) {
            return;
        }

        const canSplitHorizontally = node.h >= this.bsp.minPartitionSize * 2;
        const canSplitVertically = node.w >= this.bsp.minPartitionSize * 2;

        if (!canSplitHorizontally && !canSplitVertically) {
            return;
        }

        let splitHorizontal;

        if (canSplitHorizontally && canSplitVertically) {
            splitHorizontal = Math.random() > 0.5;
        } else {
            splitHorizontal = canSplitHorizontally;
        }

        if (splitHorizontal) {
            const split = Phaser.Math.Between(this.bsp.minPartitionSize, node.h - this.bsp.minPartitionSize);

            node.left = new BSPNode(node.x, node.y, node.w, split);
            node.right = new BSPNode(node.x, node.y + split, node.w, node.h - split);
        } else {
            const split = Phaser.Math.Between(this.bsp.minPartitionSize, node.w - this.bsp.minPartitionSize);

            node.left = new BSPNode(node.x, node.y, split, node.h);
            node.right = new BSPNode(node.x + split, node.y, node.w - split, node.h);
        }

        this.splitNode(node.left, depth + 1);
        this.splitNode(node.right, depth + 1);
    }

    createRooms(node) {
        if (node.left || node.right) {
            if (node.left) this.createRooms(node.left);
            if (node.right) this.createRooms(node.right);
            return;
        }

        const pad = this.bsp.roomPadding;
        const maxRoomWidth = node.w - pad * 2;
        const maxRoomHeight = node.h - pad * 2;
        if (maxRoomWidth < this.bsp.minRoomWidth || maxRoomHeight < this.bsp.minRoomHeight) {
            return;
        }

        const room = this.generateAspectRatioRoom(node,maxRoomWidth, maxRoomHeight, pad);
        if (!room) {
            return;
        }

        node.room = room;
        this.level.addRoom(room);
        for (let y = room.y; y < room.y + room.h; y++) {
            for (let x = room.x; x < room.x + room.w; x++) {
                this.level.setTile(x, y, 1);
            }
        }
    }

    generateAspectRatioRoom(node, maxRoomWidth, maxRoomHeight, pad) {
        for (let attempt = 0; attempt < this.bsp.maxRoomPlacementAttempts; attempt++) {
            const roomWidth = Phaser.Math.Between(
                this.bsp.minRoomWidth,
                maxRoomWidth
            );
            const roomHeight = Phaser.Math.Between(
                this.bsp.minRoomHeight,
                maxRoomHeight
            );

            const ratio = roomWidth / roomHeight;
            if (ratio < this.bsp.minAspectRatio || ratio > this.bsp.maxAspectRatio) {
                continue;
            }

            const minX = node.x + pad;
            const maxX = node.x + node.w - roomWidth - pad;
            const minY = node.y + pad;
            const maxY = node.y + node.h - roomHeight - pad;
            if (minX > maxX || minY > maxY) {
                continue;
            }

            const roomX = Phaser.Math.Between(minX, maxX);
            const roomY = Phaser.Math.Between(minY, maxY);

            return {
                x: roomX,
                y: roomY,
                w: roomWidth,
                h: roomHeight,
                centerX: Math.floor(roomX + roomWidth / 2),
                centerY: Math.floor(roomY + roomHeight / 2)
            };
        }

        return null;
    }

    connectRooms(node) {
        if (!node.left || !node.right) {
            return;
        }

        this.connectRooms(node.left);
        this.connectRooms(node.right);
        const leftRoom = this.getRoomFromNode(node.left);
        const rightRoom = this.getRoomFromNode(node.right);

        if (!leftRoom || !rightRoom) {
            return;
        }

        this.makeCorridor( leftRoom.centerX, leftRoom.centerY, rightRoom.centerX, rightRoom.centerY);
    }

    getRoomFromNode(node) {
        if (node.room) {
            return node.room;
        }

        const leftRoom = node.left ? this.getRoomFromNode(node.left) : null;
        const rightRoom = node.right ? this.getRoomFromNode(node.right) : null;
        if (leftRoom && rightRoom) {
            return Math.random() > 0.5 ? leftRoom : rightRoom;
        }

        return leftRoom || rightRoom;
    }

    makeCorridor(x1, y1, x2, y2) {
        if (Math.random() > 0.5) {
            this.carveHorizontalTunnel(x1, x2, y1);
            this.carveVerticalTunnel(y1, y2, x2);
        } else {
            this.carveVerticalTunnel(y1, y2, x1);
            this.carveHorizontalTunnel(x1, x2, y2);
        }
    }

    carveHorizontalTunnel(x1, x2, y) {
        const start = Math.min(x1, x2);
        const end = Math.max(x1, x2);

        for (let x = start; x <= end; x++) {
            if (this.level.isInside(x, y)) {
                this.level.setTile(x, y, 1);
            }
        }
    }

    carveVerticalTunnel(y1, y2, x) {
        const start = Math.min(y1, y2);
        const end = Math.max(y1, y2);
        for (let y = start; y <= end; y++) {
            if (this.level.isInside(x, y)) {
                this.level.setTile(x, y, 1);
            }
        }
    }

    calculateMetadata() {
        let floorCount = 0;
        let wallCount = 0;
        for (let y = 0; y < this.level.height; y++) {
            for (let x = 0; x < this.level.width; x++) {
                const tile = this.level.getTile(x, y);

                if (tile === 0) {
                    wallCount++;
                } else {
                    floorCount++;
                }
            }
        }

        const totalTiles = this.level.width * this.level.height;
        const actualFloorRatio = totalTiles > 0 ? floorCount / totalTiles : 0;

        this.level.metadata.algorithm = 'BSP';
        this.level.metadata.mapSize = `${this.general.mapWidth} x ${this.general.mapHeight}`;
        this.level.metadata.roomCount = this.level.rooms.length;
        this.level.metadata.minPartitionSize = this.bsp.minPartitionSize;
        this.level.metadata.maxDepth = this.bsp.maxDepth;
        this.level.metadata.roomPadding = this.bsp.roomPadding;
        this.level.metadata.minRoomWidth = this.bsp.minRoomWidth;
        this.level.metadata.minRoomHeight = this.bsp.minRoomHeight;
        this.level.metadata.minAspectRatio = this.bsp.minAspectRatio;
        this.level.metadata.maxAspectRatio = this.bsp.maxAspectRatio;
        this.level.metadata.maxRoomPlacementAttempts = this.bsp.maxRoomPlacementAttempts;
        this.level.metadata.floorCount = floorCount;
        this.level.metadata.wallCount = wallCount;
        this.level.metadata.actualFloorRatio = actualFloorRatio.toFixed(3);
    }
}