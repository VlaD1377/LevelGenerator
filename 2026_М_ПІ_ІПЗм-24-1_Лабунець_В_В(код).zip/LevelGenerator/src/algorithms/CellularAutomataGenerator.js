import LevelModel from '../core/LevelModel.js';

export default class CellularAutomataGenerator {
    generate(config) {
        const general = config.general || {};
        const cellularAutomata = config.cellularAutomata || {};

        const defaultGeneral = {
            mapWidth: 100,
            mapHeight: 60
        };

        const defaultCA = {
            initialWallChance: 0.45,
            iterations: 5,
            birthLimit: 4,
            deathLimit: 3
        };

        this.general = { ...defaultGeneral, ...general };
        this.ca = { ...defaultCA, ...cellularAutomata };
        this.level = new LevelModel(this.general.mapWidth, this.general.mapHeight, 0);
        this.initializeRandomMap();

        for (let i = 0; i < this.ca.iterations; i++) {
            this.simulateStep();
        }

        this.convertToLevelTiles();
        this.calculateMetadata();
        return this.level;
    }

    initializeRandomMap() {
        this.map = [];

        for (let y = 0; y < this.general.mapHeight; y++) {
            this.map[y] = [];

            for (let x = 0; x < this.general.mapWidth; x++) {
                const isBorder = x === 0 || y === 0 || x === this.general.mapWidth - 1 || y === this.general.mapHeight - 1;

                if (isBorder) {
                    this.map[y][x] = 1;
                } else {
                    this.map[y][x] =
                        Math.random() < this.ca.initialWallChance ? 1 : 0;
                }
            }
        }
    }

    simulateStep() {
        const newMap = [];

        for (let y = 0; y < this.general.mapHeight; y++) {
            newMap[y] = [];

            for (let x = 0; x < this.general.mapWidth; x++) {
                const isBorder = x === 0 || y === 0 || x === this.general.mapWidth - 1 || y === this.general.mapHeight - 1;

                if (isBorder) {
                    newMap[y][x] = 1;
                    continue;
                }

                const neighboringWalls = this.countWallNeighbors(x, y);
                if (this.map[y][x] === 1) {
                    newMap[y][x] =
                        neighboringWalls >= this.ca.deathLimit ? 1 : 0;
                } else {
                    newMap[y][x] =
                        neighboringWalls > this.ca.birthLimit ? 1 : 0;
                }
            }
        }

        this.map = newMap;
    }

    countWallNeighbors(x, y) {
        let count = 0;

        for (let offsetY = -1; offsetY <= 1; offsetY++) {
            for (let offsetX = -1; offsetX <= 1; offsetX++) {
                if (offsetX === 0 && offsetY === 0) {
                    continue;
                }

                const nx = x + offsetX;
                const ny = y + offsetY;

                if (
                    nx < 0 ||
                    ny < 0 ||
                    nx >= this.general.mapWidth ||
                    ny >= this.general.mapHeight
                ) {
                    count++;
                } else if (this.map[ny][nx] === 1) {
                    count++;
                }
            }
        }

        return count;
    }

    convertToLevelTiles() {
        for (let y = 0; y < this.general.mapHeight; y++) {
            for (let x = 0; x < this.general.mapWidth; x++) {
                if (this.map[y][x] === 1) {
                    this.level.setTile(x, y, 0);
                } else {
                    this.level.setTile(x, y, 1);
                }
            }
        }
    }

    calculateMetadata() {
        let floorCount = 0;
        let wallCount = 0;

        for (let y = 0; y < this.level.height; y++) {
            for (let x = 0; x < this.level.width; x++) {
                const tile = this.level.getTile(x, y);

                if (tile === 0) {
                    wallCount++;
                } else {
                    floorCount++;
                }
            }
        }

        const totalTiles = this.level.width * this.level.height;
        const actualFloorRatio = totalTiles > 0 ? floorCount / totalTiles : 0;

        this.level.metadata.algorithm = 'Cellular Automata';
        this.level.metadata.mapSize = `${this.general.mapWidth} x ${this.general.mapHeight}`;
        this.level.metadata.initialWallChance = this.ca.initialWallChance;
        this.level.metadata.iterations = this.ca.iterations;
        this.level.metadata.birthLimit = this.ca.birthLimit;
        this.level.metadata.deathLimit = this.ca.deathLimit;
        this.level.metadata.floorCount = floorCount;
        this.level.metadata.wallCount = wallCount;
        this.level.metadata.actualFloorRatio = actualFloorRatio.toFixed(3);
    }
}