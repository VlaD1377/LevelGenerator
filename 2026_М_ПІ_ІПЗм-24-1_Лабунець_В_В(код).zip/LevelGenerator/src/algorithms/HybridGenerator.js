import LevelModel from '../core/LevelModel.js';

class BSPNode {
    constructor(x, y, w, h) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.left = null;
        this.right = null;
        this.room = null;
        this.roomIndex = -1;
    }

    isLeaf() {
        return !this.left && !this.right;
    }
}

export default class HybridGenerator {
    generate(config) {
        const general = config.general || {};
        const hybrid = config.hybrid || {};

        const defaultGeneral = {
            mapWidth: 100,
            mapHeight: 60
        };

        const defaultHybrid = {
            minPartitionSize: 18,
            maxDepth: 4,
            roomPadding: 2,
            minRoomWidth: 10,
            minRoomHeight: 8,
            minAspectRatio: 0.7,
            maxAspectRatio: 1.8,
            maxRoomPlacementAttempts: 20,
            
            shellMargin: 4,
            shellNoiseChance: 0.52,
            shellIterations: 2,
            caBirthLimit: 4,
            caDeathLimit: 3,

            corridorShellRadius: 2,
            corridorShellNoiseChance: 0.56,
            corridorShellIterations: 1,

            leafInnerWallThickness: 1
        };

        this.general = { ...defaultGeneral, ...general };
        this.hybrid = { ...defaultHybrid, ...hybrid };

        this.level = new LevelModel( this.general.mapWidth, this.general.mapHeight, 0);

        this.leafNodes = [];
        this.roomEntryPoints = new Map();
        const root = new BSPNode(1, 1, this.general.mapWidth - 2, this.general.mapHeight - 2);

        this.splitNode(root, 0);
        this.collectLeafNodes(root);
        this.createRooms(root);
        const mstEdges = this.buildMST(this.level.rooms);

        this.assignDoorsToMSTEdges(mstEdges);
        this.buildLeafStructures();
        this.connectRoomsByMST(mstEdges);
        this.applyCorridorRoughness(mstEdges);
        this.recarveCorridorCores(mstEdges);
        this.ensureMainComponentOnly();
        this.calculateMetadata(mstEdges.length);

        return this.level;
    }

    splitNode(node, depth) {
        if (depth >= this.hybrid.maxDepth) {
            return;
        }

        const minSize = this.hybrid.minPartitionSize;

        const canSplitHorizontally = node.h >= minSize * 2;
        const canSplitVertically = node.w >= minSize * 2;

        if (!canSplitHorizontally && !canSplitVertically) {
            return;
        }

        let splitHorizontal;

        if (canSplitHorizontally && canSplitVertically) {
            const ratio = node.w / node.h;

            if (ratio > 1.25) {
                splitHorizontal = false;
            } else if (ratio < 0.8) {
                splitHorizontal = true;
            } else {
                splitHorizontal = Math.random() > 0.5;
            }
        } else {
            splitHorizontal = canSplitHorizontally;
        }

        if (splitHorizontal) {
            const split = Phaser.Math.Between(minSize, node.h - minSize);

            node.left = new BSPNode(node.x, node.y, node.w, split);
            node.right = new BSPNode(node.x, node.y + split, node.w, node.h - split);
        } else {
            const split = Phaser.Math.Between(minSize, node.w - minSize);

            node.left = new BSPNode(node.x, node.y, split, node.h);
            node.right = new BSPNode(node.x + split, node.y, node.w - split, node.h);
        }

        this.splitNode(node.left, depth + 1);
        this.splitNode(node.right, depth + 1);
    }

    collectLeafNodes(node) {
        if (!node) {
            return;
        }

        if (node.isLeaf()) {
            this.leafNodes.push(node);
            return;
        }

        this.collectLeafNodes(node.left);
        this.collectLeafNodes(node.right);
    }

    createRooms(node) {
        if (!node) {
            return;
        }

        if (!node.isLeaf()) {
            this.createRooms(node.left);
            this.createRooms(node.right);
            return;
        }
        const pad = this.hybrid.roomPadding;
        const maxRoomWidth = node.w - pad * 2;
        const maxRoomHeight = node.h - pad * 2;

        if (maxRoomWidth < this.hybrid.minRoomWidth || maxRoomHeight < this.hybrid.minRoomHeight) {
            return;
        }
        const room = this.generateRoomWithAspectRatio(node, maxRoomWidth, maxRoomHeight, pad);

        if (!room) {
            return;
        }

        node.room = room;
        node.roomIndex = this.level.rooms.length;
        this.level.addRoom(room);
    }

    generateRoomWithAspectRatio(node, maxRoomWidth, maxRoomHeight, pad) {
        for (let attempt = 0; attempt < this.hybrid.maxRoomPlacementAttempts; attempt++) {
            const roomWidth = Phaser.Math.Between(this.hybrid.minRoomWidth, maxRoomWidth);
            const roomHeight = Phaser.Math.Between(this.hybrid.minRoomHeight, maxRoomHeight);
            const ratio = roomWidth / roomHeight;

            if (ratio < this.hybrid.minAspectRatio || ratio > this.hybrid.maxAspectRatio) {
                continue;
            }

            const minX = node.x + pad;
            const maxX = node.x + node.w - roomWidth - pad;
            const minY = node.y + pad;
            const maxY = node.y + node.h - roomHeight - pad;
            if (minX > maxX || minY > maxY) {
                continue;
            }

            const roomX = Phaser.Math.Between(minX, maxX);
            const roomY = Phaser.Math.Between(minY, maxY);

            return {
                x: roomX,
                y: roomY,
                w: roomWidth,
                h: roomHeight,
                centerX: Math.floor(roomX + roomWidth / 2),
                centerY: Math.floor(roomY + roomHeight / 2)
            };
        }

        return null;
    }

    buildMST(rooms) {
        if (rooms.length <= 1) {
            return [];
        }
        const visited = new Set();
        const edges = [];
        visited.add(0);

        while (visited.size < rooms.length) {
            let bestEdge = null;
            let bestDistance = Infinity;

            for (const fromIndex of visited) {
                for (let toIndex = 0; toIndex < rooms.length; toIndex++) {
                    if (visited.has(toIndex)) {
                        continue;
                    }

                    const roomA = rooms[fromIndex];
                    const roomB = rooms[toIndex];

                    const distance =
                        Math.abs(roomA.centerX - roomB.centerX) +
                        Math.abs(roomA.centerY - roomB.centerY);

                    if (distance < bestDistance) {
                        bestDistance = distance;
                        bestEdge = { fromIndex, toIndex, distance };
                    }
                }
            }

            if (!bestEdge) {
                break;
            }

            edges.push(bestEdge);
            visited.add(bestEdge.toIndex);
        }
        return edges;
    }

    assignDoorsToMSTEdges(edges) {
        for (const edge of edges) {
            const roomA = this.level.rooms[edge.fromIndex];
            const roomB = this.level.rooms[edge.toIndex];
            const pointA = this.getDoorPointToward(roomA, roomB);
            const pointB = this.getDoorPointToward(roomB, roomA);

            edge.pointA = pointA;
            edge.pointB = pointB;

            this.addRoomEntryPoint(edge.fromIndex, pointA);
            this.addRoomEntryPoint(edge.toIndex, pointB);
        }
    }

    addRoomEntryPoint(roomIndex, point) {
        if (!this.roomEntryPoints.has(roomIndex)) {
            this.roomEntryPoints.set(roomIndex, []);
        }

        this.roomEntryPoints.get(roomIndex).push(point);
    }

    getDoorPointToward(room, targetRoom) {
        const dx = targetRoom.centerX - room.centerX;
        const dy = targetRoom.centerY - room.centerY;

        if (Math.abs(dx) > Math.abs(dy)) {
            if (dx > 0) {
                return {
                    x: room.x + room.w - 1,
                    y: Phaser.Math.Between(room.y + 1, room.y + room.h - 2)
                };
            }

            return {
                x: room.x,
                y: Phaser.Math.Between(room.y + 1, room.y + room.h - 2)
            };
        }

        if (dy > 0) {
            return {
                x: Phaser.Math.Between(room.x + 1, room.x + room.w - 2),
                y: room.y + room.h - 1
            };
        }

        return {
            x: Phaser.Math.Between(room.x + 1, room.x + room.w - 2),
            y: room.y
        };
    }

    buildLeafStructures() {
        for (const leaf of this.leafNodes) {
            if (!leaf.room || leaf.roomIndex < 0) {
                continue;
            }

            const entryPoints = this.roomEntryPoints.get(leaf.roomIndex) || [];
            this.buildSingleLeafStructure(leaf, entryPoints);
        }
    }

    buildSingleLeafStructure(leaf, entryPoints) {
        const localWidth = leaf.w;
        const localHeight = leaf.h;
        const room = leaf.room;
        const wallThickness = this.hybrid.leafInnerWallThickness;
        const shellMargin = this.hybrid.shellMargin;

        const localMap = Array.from({ length: localHeight }, () => Array(localWidth).fill(1));
        const roomLocalX = room.x - leaf.x;
        const roomLocalY = room.y - leaf.y;

        for (let y = roomLocalY; y < roomLocalY + room.h; y++) {
            for (let x = roomLocalX; x < roomLocalX + room.w; x++) {
                if (x >= wallThickness && y >= wallThickness && x < localWidth - wallThickness && y < localHeight - wallThickness) {
                    localMap[y][x] = 0;
                }
            }
        }

        this.applyOuterRoomShell(localMap, localWidth, localHeight, roomLocalX, roomLocalY, room.w, room.h, shellMargin, wallThickness);

        for (const point of entryPoints) {
            const lx = point.x - leaf.x;
            const ly = point.y - leaf.y;
            this.carveDoorPocket(localMap, lx, ly, localWidth, localHeight, wallThickness);
            this.carveLocalPathToRoom(localMap, lx, ly, roomLocalX, roomLocalY, room.w, room.h);
        }

        for (let y = 0; y < localHeight; y++) {
            for (let x = 0; x < localWidth; x++) {
                this.level.setTile(
                    leaf.x + x,
                    leaf.y + y,
                    localMap[y][x] === 0 ? 1 : 0
                );
            }
        }
    }

    applyOuterRoomShell(localMap, width, height, roomX, roomY, roomW, roomH, shellMargin, border = 1) {
        const areaMinX = Math.max(border, roomX - shellMargin);
        const areaMaxX = Math.min(width - border - 1, roomX + roomW + shellMargin - 1);
        const areaMinY = Math.max(border, roomY - shellMargin);
        const areaMaxY = Math.min(height - border - 1, roomY + roomH + shellMargin - 1);

        for (let y = areaMinY; y <= areaMaxY; y++) {
            for (let x = areaMinX; x <= areaMaxX; x++) {
                const insideRoom =
                    x >= roomX &&
                    y >= roomY &&
                    x < roomX + roomW &&
                    y < roomY + roomH;

                if (insideRoom) {
                    continue;
                }

                localMap[y][x] = Math.random() < this.hybrid.shellNoiseChance ? 1 : 0;
            }
        }

        for (let i = 0; i < this.hybrid.shellIterations; i++) {
            this.simulateCALimited(localMap, width, height, areaMinX, areaMinY, areaMaxX - areaMinX + 1, areaMaxY - areaMinY + 1, border);

            for (let y = roomY; y < roomY + roomH; y++) {
                for (let x = roomX; x < roomX + roomW; x++) {
                    localMap[y][x] = 0;
                }
            }
        }

        for (let y = roomY; y < roomY + roomH; y++) {
            for (let x = roomX; x < roomX + roomW; x++) {
                localMap[y][x] = 0;
            }
        }
    }

    carveDoorPocket(localMap, x, y, width, height, border = 1) {
        for (let yy = y - 1; yy <= y + 1; yy++) {
            for (let xx = x - 1; xx <= x + 1; xx++) {
                if (xx >= border &&
                    yy >= border &&
                    xx < width - border &&
                    yy < height - border)
                {
                    localMap[yy][xx] = 0;
                }
            }
        }
    }

    carveLocalPathToRoom(localMap, x, y, roomX, roomY, roomW, roomH) {
        const targetX = Phaser.Math.Clamp(x, roomX, roomX + roomW - 1);
        const targetY = Phaser.Math.Clamp(y, roomY, roomY + roomH - 1);
        this.carveLocalPath(localMap, x, y, targetX, targetY);
    }

    carveLocalPath(localMap, x1, y1, x2, y2) {
        let x = x1;
        let y = y1;

        while (x !== x2) {
            localMap[y][x] = 0;
            x += x < x2 ? 1 : -1;
        }

        while (y !== y2) {
            localMap[y][x] = 0;
            y += y < y2 ? 1 : -1;
        }
        localMap[y][x] = 0;
    }

    simulateCALimited(localMap, width, height, areaX, areaY, areaW, areaH, border = 1) {
        const newMap = localMap.map(row => [...row]);

        const startX = Math.max(border, areaX);
        const startY = Math.max(border, areaY);
        const endX = Math.min(width - border - 1, areaX + areaW - 1);
        const endY = Math.min(height - border - 1, areaY + areaH - 1);

        for (let y = startY; y <= endY; y++) {
            for (let x = startX; x <= endX; x++) {
                const neighboringWalls = this.countLocalWallNeighbors(localMap, x, y, width, height);

                if (localMap[y][x] === 1) {
                    newMap[y][x] = neighboringWalls >= this.hybrid.caDeathLimit ? 1 : 0;
                } else {
                    newMap[y][x] = neighboringWalls > this.hybrid.caBirthLimit ? 1 : 0;
                }
            }
        }

        for (let y = startY; y <= endY; y++) {
            for (let x = startX; x <= endX; x++) {
                localMap[y][x] = newMap[y][x];
            }
        }
    }

    countLocalWallNeighbors(localMap, x, y, width, height) {
        let count = 0;

        for (let oy = -1; oy <= 1; oy++) {
            for (let ox = -1; ox <= 1; ox++) {
                if (ox === 0 && oy === 0) {
                    continue;
                }

                const nx = x + ox;
                const ny = y + oy;

                if (nx < 0 || ny < 0 || nx >= width || ny >= height) {
                    count++;
                } else if (localMap[ny][nx] === 1) {
                    count++;
                }
            }
        }
        return count;
    }

    connectRoomsByMST(edges) {
        for (const edge of edges) {
            const corridorData = this.createCorridor(edge.pointA.x, edge.pointA.y, edge.pointB.x,edge.pointB.y);
            edge.corridorCells = corridorData.cells;
            edge.bendPoint = corridorData.bendPoint;
        }
    }

    createCorridor(x1, y1, x2, y2) {
        const cells = [];
        let bendPoint = null;

        if (Math.random() > 0.5) {
            cells.push(...this.carveHorizontalTunnel(x1, x2, y1));
            bendPoint = { x: x2, y: y1 };
            cells.push(...this.carveVerticalTunnel(y1, y2, x2));
        } else {
            cells.push(...this.carveVerticalTunnel(y1, y2, x1));
            bendPoint = { x: x1, y: y2 };
            cells.push(...this.carveHorizontalTunnel(x1, x2, y2));
        }

        return {
            cells: this.uniqueCells(cells),
            bendPoint
        };
    }

    carveHorizontalTunnel(x1, x2, y) {
        const cells = [];
        const start = Math.min(x1, x2);
        const end = Math.max(x1, x2);

        for (let x = start; x <= end; x++) {
            if (this.level.isInside(x, y)) {
                this.level.setTile(x, y, 1);
                cells.push({ x, y });
            }
        }

        return cells;
    }

    carveVerticalTunnel(y1, y2, x) {
        const cells = [];
        const start = Math.min(y1, y2);
        const end = Math.max(y1, y2);

        for (let y = start; y <= end; y++) {
            if (this.level.isInside(x, y)) {
                this.level.setTile(x, y, 1);
                cells.push({ x, y });
            }
        }

        return cells;
    }

    uniqueCells(cells) {
        const seen = new Set();
        const result = [];

        for (const cell of cells) {
            const key = `${cell.x},${cell.y}`;
            if (!seen.has(key)) {
                seen.add(key);
                result.push(cell);
            }
        }

        return result;
    }

    applyCorridorRoughness(edges) {
        for (const edge of edges) {
            if (!edge.corridorCells || edge.corridorCells.length === 0) {
                continue;
            }

            this.applyRoughShellAroundCorridor(edge.corridorCells, edge.pointA, edge.pointB, edge.bendPoint);
        }
    }

    applyRoughShellAroundCorridor(cells, startPoint, endPoint, bendPoint = null) {
        const radius = this.hybrid.corridorShellRadius;

        const minX = Math.max(1, Math.min(...cells.map(c => c.x)) - radius);
        const maxX = Math.min(this.level.width - 2, Math.max(...cells.map(c => c.x)) + radius);
        const minY = Math.max(1, Math.min(...cells.map(c => c.y)) - radius);
        const maxY = Math.min(this.level.height - 2, Math.max(...cells.map(c => c.y)) + radius);

        const localWidth = maxX - minX + 1;
        const localHeight = maxY - minY + 1;

        const localMap = Array.from({ length: localHeight }, (_, y) =>
            Array.from({ length: localWidth }, (_, x) => this.level.getTile(minX + x, minY + y) === 1 ? 0 : 1)
        );

        const protectedSet = new Set();

        for (const cell of cells) {
            protectedSet.add(`${cell.x - minX},${cell.y - minY}`);
        }

        this.addProtectedPocket(protectedSet, startPoint.x - minX, startPoint.y - minY, localWidth, localHeight, 1);
        this.addProtectedPocket(protectedSet, endPoint.x - minX, endPoint.y - minY, localWidth, localHeight, 1);

        if (bendPoint) {
            this.addProtectedPocket(protectedSet, bendPoint.x - minX, bendPoint.y - minY, localWidth, localHeight, 1);
        }

        for (const cell of cells) {
            const cx = cell.x - minX;
            const cy = cell.y - minY;

            for (let y = cy - radius; y <= cy + radius; y++) {
                for (let x = cx - radius; x <= cx + radius; x++) {
                    if (x <= 0 || y <= 0 || x >= localWidth - 1 || y >= localHeight - 1) {
                        continue;
                    }

                    const dist = Math.abs(x - cx) + Math.abs(y - cy);
                    if (dist > radius) {
                        continue;
                    }

                    const key = `${x},${y}`;
                    if (protectedSet.has(key)) {
                        continue;
                    }

                    localMap[y][x] = Math.random() < this.hybrid.corridorShellNoiseChance ? 1 : 0;
                }
            }
        }

        for (let i = 0; i < this.hybrid.corridorShellIterations; i++) {
            this.simulateCALimited(localMap, localWidth, localHeight, 1, 1, localWidth - 2, localHeight - 2, 1);

            for (const key of protectedSet) {
                const [x, y] = key.split(',').map(Number);
                localMap[y][x] = 0;
            }
        }

        for (const key of protectedSet) {
            const [x, y] = key.split(',').map(Number);
            localMap[y][x] = 0;
        }

        for (let y = 0; y < localHeight; y++) {
            for (let x = 0; x < localWidth; x++) {
                this.level.setTile(minX + x, minY + y, localMap[y][x] === 0 ? 1 : 0);
            }
        }
    }

    addProtectedPocket(protectedSet, cx, cy, width, height, radius = 1) {
        for (let y = cy - radius; y <= cy + radius; y++) {
            for (let x = cx - radius; x <= cx + radius; x++) {
                if (x >= 0 && y >= 0 && x < width && y < height) {
                    protectedSet.add(`${x},${y}`);
                }
            }
        }
    }

    recarveCorridorCores(edges) {
        for (const edge of edges) {
            if (!edge.corridorCells) {
                continue;
            }

            for (const cell of edge.corridorCells) {
                if (this.level.isInside(cell.x, cell.y)) {
                    this.level.setTile(cell.x, cell.y, 1);
                }
            }

            if (edge.pointA && this.level.isInside(edge.pointA.x, edge.pointA.y)) {
                this.level.setTile(edge.pointA.x, edge.pointA.y, 1);
            }

            if (edge.pointB && this.level.isInside(edge.pointB.x, edge.pointB.y)) {
                this.level.setTile(edge.pointB.x, edge.pointB.y, 1);
            }

            if (edge.bendPoint && this.level.isInside(edge.bendPoint.x, edge.bendPoint.y)) {
                this.level.setTile(edge.bendPoint.x, edge.bendPoint.y, 1);
            }
        }
    }

    ensureMainComponentOnly() {
        const visited = Array.from({ length: this.level.height }, () =>
            Array(this.level.width).fill(false)
        );

        const components = [];

        for (let y = 0; y < this.level.height; y++) {
            for (let x = 0; x < this.level.width; x++) {
                if (visited[y][x] || this.level.getTile(x, y) !== 1) {
                    continue;
                }

                const component = this.floodFillFloor(x, y, visited);
                components.push(component);
            }
        }

        if (components.length <= 1) {
            return;
        }

        components.sort((a, b) => b.length - a.length);
        const mainComponent = new Set(
            components[0].map(cell => `${cell.x},${cell.y}`)
        );

        for (let y = 0; y < this.level.height; y++) {
            for (let x = 0; x < this.level.width; x++) {
                if (this.level.getTile(x, y) === 1 && !mainComponent.has(`${x},${y}`)) {
                    this.level.setTile(x, y, 0);
                }
            }
        }
    }

    floodFillFloor(startX, startY, visited) {
        const queue = [{ x: startX, y: startY }];
        const component = [];

        visited[startY][startX] = true;

        const dirs = [
            { x: 1, y: 0 },
            { x: -1, y: 0 },
            { x: 0, y: 1 },
            { x: 0, y: -1 }
        ];

        while (queue.length > 0) {
            const current = queue.shift();
            component.push(current);

            for (const d of dirs) {
                const nx = current.x + d.x;
                const ny = current.y + d.y;

                if (this.level.isInside(nx, ny) &&
                    !visited[ny][nx] &&
                    this.level.getTile(nx, ny) === 1)
                {
                    visited[ny][nx] = true;
                    queue.push({ x: nx, y: ny });
                }
            }
        }

        return component;
    }

    calculateMetadata(mstEdgeCount) {
        this.level.metadata.algorithm = 'Hybrid';
        this.level.metadata.mapSize = `${this.general.mapWidth} x ${this.general.mapHeight}`;
        this.level.metadata.roomCount = this.level.rooms.length;
        this.level.metadata.mstEdgeCount = mstEdgeCount;
    }
}