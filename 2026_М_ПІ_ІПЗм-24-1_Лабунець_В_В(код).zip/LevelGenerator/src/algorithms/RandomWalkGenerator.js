import LevelModel from '../core/LevelModel.js';

export default class RandomWalkGenerator {
    generate(config) {
        const general = config.general || {};
        const randomWalk = config.randomWalk || {};

        const defaultGeneral = {
            mapWidth: 100,
            mapHeight: 60
        };

        const defaultRandomWalk = {
            maxStepsMultiplier: 20,
            startFromCenter: true,
            targetFloorRatio: 0.35
        };

        this.general = { ...defaultGeneral, ...general };
        this.randomWalk = { ...defaultRandomWalk, ...randomWalk };

        this.level = new LevelModel(this.general.mapWidth, this.general.mapHeight,0);
        
        this.initializeMap();
        this.runWalker();
        this.keepLargestRegion();
        this.convertToLevelTiles();
        this.calculateMetadata();

        return this.level;
    }

    initializeMap() {
        this.map = [];

        for (let y = 0; y < this.general.mapHeight; y++) {
            this.map[y] = [];
            for (let x = 0; x < this.general.mapWidth; x++) {
                this.map[y][x] = 1;
            }
        }
    }

    runWalker() {
        const totalTiles = this.general.mapWidth * this.general.mapHeight;
        const targetFloorTiles = Math.floor(totalTiles * this.randomWalk.targetFloorRatio);
        const maxSteps = totalTiles * this.randomWalk.maxStepsMultiplier;

        let x = this.randomWalk.startFromCenter ? Math.floor(this.general.mapWidth / 2) : Phaser.Math.Between(1, this.general.mapWidth - 2);
        let y = this.randomWalk.startFromCenter ? Math.floor(this.general.mapHeight / 2) : Phaser.Math.Between(1, this.general.mapHeight - 2);
        let floorCount = 0;
        let steps = 0;

        while (floorCount < targetFloorTiles && steps < maxSteps) {
            if (this.map[y][x] === 1) {
                this.map[y][x] = 0;
                floorCount++;
            }

            const direction = Phaser.Math.Between(0, 3);

            switch (direction) {
                case 0: x += 1; break;
                case 1: x -= 1; break;
                case 2: y += 1; break;
                case 3: y -= 1; break;
            }

            x = Phaser.Math.Clamp(x, 1, this.general.mapWidth - 2);
            y = Phaser.Math.Clamp(y, 1, this.general.mapHeight - 2);
            steps++;
        }

        this.generatedSteps = steps;
        this.generatedFloorCount = floorCount;
    }

    keepLargestRegion() {
        const visited = Array.from({ length: this.general.mapHeight }, () => Array(this.general.mapWidth).fill(false));
        const regions = [];

        for (let y = 1; y < this.general.mapHeight - 1; y++) {
            for (let x = 1; x < this.general.mapWidth - 1; x++) {
                if (!visited[y][x] && this.map[y][x] === 0) {
                    const region = this.floodFill(x, y, visited);
                    if (region.length > 0) {
                        regions.push(region);
                    }
                }
            }
        }

        if (regions.length === 0) {
            return;
        }

        regions.sort((a, b) => b.length - a.length);
        const largest = regions[0];
        const keepSet = new Set(largest.map(cell => `${cell.x},${cell.y}`));

        for (let y = 1; y < this.general.mapHeight - 1; y++) {
            for (let x = 1; x < this.general.mapWidth - 1; x++) {
                if (this.map[y][x] === 0 && !keepSet.has(`${x},${y}`)) {
                    this.map[y][x] = 1;
                }
            }
        }
    }

    floodFill(startX, startY, visited) {
        const queue = [{ x: startX, y: startY }];
        const region = [];

        visited[startY][startX] = true;

        const directions = [
            { x: 1, y: 0 },
            { x: -1, y: 0 },
            { x: 0, y: 1 },
            { x: 0, y: -1 }
        ];

        while (queue.length > 0) {
            const current = queue.shift();
            region.push(current);

            for (const dir of directions) {
                const nx = current.x + dir.x;
                const ny = current.y + dir.y;

                if (nx > 0 && ny > 0 &&
                    nx < this.general.mapWidth - 1 && ny < this.general.mapHeight - 1 &&
                    !visited[ny][nx] && this.map[ny][nx] === 0)
                {
                    visited[ny][nx] = true;
                    queue.push({ x: nx, y: ny });
                }
            }
        }
        return region;
    }

    convertToLevelTiles() {
        for (let y = 0; y < this.general.mapHeight; y++) {
            for (let x = 0; x < this.general.mapWidth; x++) {
                this.level.setTile(x, y, this.map[y][x] === 0 ? 1 : 0);
            }
        }
    }

    calculateMetadata() {
        this.level.metadata.algorithm = 'Random Walk';
        this.level.metadata.mapSize = `${this.general.mapWidth} x ${this.general.mapHeight}`;
        this.level.metadata.steps = this.generatedSteps;
        this.level.metadata.floorCount = this.generatedFloorCount;
        this.level.metadata.targetFloorRatio = this.general.targetFloorRatio;
    }
}