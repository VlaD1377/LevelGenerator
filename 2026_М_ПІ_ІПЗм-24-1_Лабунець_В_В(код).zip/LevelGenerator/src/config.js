const generationConfig = {
    general: {
        algorithm: 'BSP',
        mapWidth: 200,
        mapHeight: 120,
        tileSize: 7
    },

    bsp: {
        minPartitionSize: 14,
        maxDepth: 5,
        roomPadding: 1,
        minRoomWidth: 5,
        minRoomHeight: 5,
        minAspectRatio: 0.65,
        maxAspectRatio: 1.7,
        maxRoomPlacementAttempts: 20
    },

    cellularAutomata: {
        initialWallChance: 0.42,
        iterations: 5,
        birthLimit: 4,
        deathLimit: 3
    },

    perlin: {
        scale: 12,
        threshold: 0.5,
        octaves: 3,
        persistence: 0.5,
        smoothSteps: 1
    },

    randomWalk: {
        maxStepsMultiplier: 20,
        startFromCenter: true,
        targetFloorRatio: 0.3
    },

    hybrid: {
        minPartitionSize: 18,
        maxDepth: 5,
        roomPadding: 3,
        minRoomWidth: 5,
        minRoomHeight: 5,
        minAspectRatio: 0.5,
        maxAspectRatio: 2.0,
        maxRoomPlacementAttempts: 20,

        shellMargin: 10,
        shellNoiseChance: 0.45,
        shellIterations: 5,
        caBirthLimit: 4,
        caDeathLimit: 3,

        corridorShellRadius: 3,
        corridorShellNoiseChance: 0.52,
        corridorShellIterations: 1,

        leafInnerWallThickness: 1
    }
};

export default generationConfig;